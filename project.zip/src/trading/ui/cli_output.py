"""trading.ui.cli_output

Unified Rich-based helpers for console output in CLIs & notebooks.

Currently wraps `results_ui.ResultsRenderer` (legacy) so existing visual
components keep working after the refactor.  In the future we can move the
class here directly but importing keeps the diff minimal.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

import pandas as pd
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box
from rich.progress import Progress, SpinnerColumn, TextColumn

# Re-use existing renderer without moving its heavy code right now
try:
    from results_ui import ResultsRenderer  # type: ignore  # noqa: WPS433
except ModuleNotFoundError:  # fallback if file was removed or not on path
    ResultsRenderer = None  # type: ignore

logger = logging.getLogger(__name__)

__all__ = [
    "render_predictions",
    "render_summary",
]

console = Console()


def render_predictions(df: pd.DataFrame, limit: int = 30) -> None:  # noqa: D401
    """Pretty-print the *df* predictions using Rich.

    Shows the first *limit* rows with coloured BUY / SELL / NONE cells.
    """
    if df.empty:
        console.print("[bold red]No predictions to show.[/]")
        return

    table = Table(box=box.SIMPLE_HEAVY)
    table.add_column("Datetime", justify="right", no_wrap=True)
    table.add_column("Price", justify="right")
    table.add_column("Pred", justify="center")
    table.add_column("Conf", justify="right")
    table.add_column("Risk", justify="center")
    
    # Add indicator columns if they exist
    indicator_cols = [col for col in df.columns if col.startswith("indicator_")]
    if indicator_cols:
        for col in indicator_cols[:2]:  # Limit to 2 indicators to keep table readable
            display_name = col.replace("indicator_", "")
            table.add_column(display_name, justify="right")

    palette = {"BUY": "green", "SELL": "red", "NONE": "yellow"}

    # Check if all prices are zero or missing
    all_prices_zero = True
    price_columns = ["Price", "Close", "Open", "Adj Close", "High", "Low"]
    
    for _, row in df.head(limit).iterrows():
        pred = str(row.get("prediction", "NONE"))
        color = palette.get(pred, "white")
        
        # Get confidence level and style
        conf = row.get("confidence", 0)
        conf_level = row.get("confidence_level", "")
        if conf >= 0.95:
            conf_style = "bold green"
        elif conf >= 0.8:
            conf_style = "green"
        elif conf >= 0.5:
            conf_style = "yellow"
        else:
            conf_style = "red"
            
        # Get price from any available price column (Close, Price, Open, etc.)
        price = 0
        for price_col in price_columns:
            if price_col in row and pd.notna(row[price_col]) and row[price_col] != 0:
                price = row[price_col]
                all_prices_zero = False
                break
        
        # Build row data
        row_data = [
            str(row.get("datetime", ""))[:19],
            f"{price:.2f}",
            f"[{color}]{pred}[/]",
            f"[{conf_style}]{conf:.2f}[/]",
            row.get("risk_tier", "LR"),
        ]
        
        # Add indicator values if they exist
        for col in indicator_cols[:2]:
            if col in row:
                indicator_value = row[col]
                row_data.append(f"{indicator_value:.2f}")
            else:
                row_data.append("N/A")
                
        table.add_row(*row_data)
    
    if all_prices_zero:
        logger.warning("All price values are zero or missing in the displayed results!")
        console.print("[bold yellow]Warning: All price values are zero or missing![/]")

    console.print(table)


def render_summary(results: Dict[str, Dict[str, Any]], title: str = "Results") -> None:  # noqa: D401
    """Display aggregate back-test results with fancy Rich visuals."""
    if ResultsRenderer is None:
        console.print("[red]Rich summary renderer unavailable (results_ui missing).[/]")
        return
    renderer = ResultsRenderer()
    renderer.display_results(results, strategy_names=list(results.keys()), title=title)
