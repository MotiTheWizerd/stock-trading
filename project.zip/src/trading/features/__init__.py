"""Feature engineering & signal detection subpackage."""

__all__: list[str] = []
