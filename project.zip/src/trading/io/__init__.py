"""IO subpackage: downloading, file management, path helpers, data fixes."""

__all__: list[str] = []
