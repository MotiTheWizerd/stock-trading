"""Top-level trading package.

Exposes high-level helper functions after refactor.
Currently empty; submodules will be imported once moves and
refactor are complete.
"""

# Placeholder public API – to be populated after restructuring

__all__: list[str] = []
