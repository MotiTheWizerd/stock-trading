"""trading.models.predictor

StockPredictor – model loading & inference wrapped in a reusable class.

This code was extracted from the previous monolithic `scripts/predict.py` so
that other parts of the application (CLI, back-tester, notebooks) can import
`trading.models.StockPredictor` without depending on the full CLI script.

The implementation is *identical* to the original; only top-level logging
setup has been removed so that applications can configure logging themselves.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
import pandas as pd

__all__ = ["StockPredictor"]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helper utilities (kept private – not exported)
# ---------------------------------------------------------------------------

def _norm(col: str) -> str:
    """Normalise a column name for loose matching.

    • lower-case
    • strip whitespace
    • remove underscores / hyphens
    """
    return (
        str(col)
        .lower()
        .replace(" ", "")
        .replace("_", "")
        .replace("-", "")
    )

# ---------------------------------------------------------------------------
# Core predictor class
# ---------------------------------------------------------------------------

class StockPredictor:
    """Load a trained model and make predictions on new feature data."""

    def __init__(self, ticker: str, model_dir: str | None = None):
        # Allow passing a direct model file path instead of a ticker
        ticker_str = str(ticker)
        if (ticker_str.endswith(".joblib") or ticker_str.endswith(".pkl")) and Path(ticker_str).exists():
            model_path = Path(ticker_str)
            self.model_dir = model_path.parent
            self.ticker = model_path.stem.split("_")[0].upper()
        else:
            self.ticker = ticker_str.upper()
            self.model_dir = Path(model_dir) if model_dir else Path("models") / self.ticker
            self.model_dir.mkdir(parents=True, exist_ok=True)

        self.model = None  # will be populated by _load_model()
        self.model_classes: list[str] = []
        self.feature_columns: list[str] = []
        self.metadata: dict[str, object] = {}

        self._load_model()

    # ---------------------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------------------

    def _load_model(self) -> None:
        """Locate and load the newest *.joblib / *.pkl model."""
        # Resolve file vs. directory cases first
        if self.model_dir.is_file() and self.model_dir.suffix in {".joblib", ".pkl"}:
            model_file = self.model_dir
            self.model_dir = model_file.parent
        else:
            if not self.model_dir.exists():
                raise FileNotFoundError(f"Model directory not found: {self.model_dir}")

            logger.info("Searching for model files in: %s", self.model_dir.absolute())
            all_files = list(self.model_dir.glob("*.joblib")) + list(self.model_dir.glob("*.pkl"))
            logger.info("Found %d model files: %s", len(all_files), [f.name for f in all_files])
            if not all_files:
                raise FileNotFoundError(f"No model files found in {self.model_dir.absolute()}")

            # Prefer base models (exclude '_calibrated.joblib') if present
            base_models = [f for f in all_files if not f.name.endswith("_calibrated.joblib")]
            search_pool = base_models or all_files
            model_file = max(search_pool, key=lambda f: f.stat().st_mtime)

        logger.info("✅ Loading model from: %s", model_file)
        self.model = joblib.load(model_file)
        self.model_classes = self.model.classes_.tolist()
        logger.info("Model classes: %s", self.model_classes)

        # Optional metadata (JSON side-car)
        metadata_file = model_file.with_suffix(".json")
        if metadata_file.exists():
            with open(metadata_file, "r", encoding="utf-8") as fh:
                self.metadata = json.load(fh)
            if "feature_columns" in self.metadata:
                self.feature_columns = self.metadata["feature_columns"]
                logger.info("Extracted %d feature columns from metadata", len(self.feature_columns))

        # Fallback – introspect the model for feature names
        if not self.feature_columns:
            logger.info("No feature columns in metadata; attempting extraction from model…")
            if hasattr(self.model, "feature_names_in_"):
                self.feature_columns = list(self.model.feature_names_in_)
            elif (
                hasattr(self.model, "named_steps")
                and self.model.named_steps.get("model") is not None
                and hasattr(self.model.named_steps["model"], "feature_names_in_")
            ):
                self.feature_columns = list(self.model.named_steps["model"].feature_names_in_)
            else:
                raise ValueError(
                    "Model does not contain feature names; re-train with feature_columns in metadata."
                )
            logger.info("Recovered %d feature columns from model", len(self.feature_columns))

    # ---------------------------------------------------------------------
    # Public API
    # ---------------------------------------------------------------------

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        """Return the input `df` enriched with predictions, probabilities & risk."""
        df_copy = df.copy()

        logger.info("Original columns: %s", df_copy.columns.tolist())
        logger.info("Model expects features: %s", self.feature_columns)

        # Soft normalisation (replace _ with space) for quick look-ups
        df_copy.columns = [str(col).replace("_", " ").strip() for col in df_copy.columns]

        # Ensure datetime column has correct dtype
        if "datetime" in df_copy.columns and not pd.api.types.is_datetime64_any_dtype(df_copy["datetime"]):
            try:
                df_copy["datetime"] = pd.to_datetime(df_copy["datetime"])
                logger.info("Converted datetime column to datetime64[ns]")
            except Exception as exc:  # noqa: BLE001
                logger.warning("Failed to convert datetime column: %s", exc)

        # -----------------------------------------------------------------
        # 1. Attempt direct column alignment
        # -----------------------------------------------------------------
        normalized_feature_columns = [col.replace("_", " ").strip() for col in self.feature_columns]
        missing_features = [c for c in normalized_feature_columns if c not in df_copy.columns]

        # -----------------------------------------------------------------
        # 2. Column name mapping heuristics if initial match fails
        # -----------------------------------------------------------------
        if missing_features:
            logger.warning("Missing features: %s", missing_features)
            column_mapping: dict[str, str] = {}
            for col in missing_features:
                variations = [
                    col.lower(),
                    col.upper(),
                    col.replace(" ", ""),
                    col.replace(" ", "_"),
                    col.replace("_", " ").strip(),
                    col.lower().replace(" ", "_"),
                    col.upper().replace(" ", "_"),
                ]
                for var in variations:
                    matches = [c for c in df_copy.columns if c.lower() == var.lower()]
                    if matches:
                        column_mapping[col] = matches[0]
                        logger.info("Mapped '%s' ➞ '%s'", col, matches[0])
                        break
            if column_mapping:
                df_copy = df_copy.rename(columns={v: k for k, v in column_mapping.items()})
                missing_features = [c for c in normalized_feature_columns if c not in df_copy.columns]

        # -----------------------------------------------------------------
        # 3. Last resort – add zero-filled columns
        # -----------------------------------------------------------------
        if missing_features:
            logger.warning("Still missing features after mapping: %s", missing_features)
            for col in missing_features:
                df_copy[col] = 0.0

        # -----------------------------------------------------------------
        # 4. Normalise names strictly to map to model order
        # -----------------------------------------------------------------
        norm_to_raw = {_norm(c): c for c in df_copy.columns}
        ordered_pairs: list[tuple[str, str]] = [
            (model_col, norm_to_raw[_norm(model_col)])
            for model_col in self.feature_columns
            if _norm(model_col) in norm_to_raw
        ]
        if not ordered_pairs:
            raise ValueError("No matching features between model and data after normalisation")

        X = df_copy[[raw for _mc, raw in ordered_pairs]].copy()
        X.columns = [mc for mc, _raw in ordered_pairs]  # rename to model’s original names

        logger.info("Feature matrix shape: %s", X.shape)

        # Fill any remaining NaNs
        if X.isna().any().any():
            X = X.fillna(0)

        # -----------------------------------------------------------------
        # 5. Inference
        # -----------------------------------------------------------------
        predictions = self.model.predict(X)
        probabilities = self.model.predict_proba(X)
        confidences = np.max(probabilities, axis=1)
        
        # Get the class with highest probability for each prediction
        highest_prob_indices = np.argmax(probabilities, axis=1)
        highest_prob_classes = [self.model_classes[i] for i in highest_prob_indices]

        # -----------------------------------------------------------------
        # 6. Assemble result frame (preserve original datetime & price columns)
        # -----------------------------------------------------------------
        essential_cols: list[str] = []
        if "datetime" in df.columns:
            essential_cols.append("datetime")
        for price_col in ["Close", "Open", "High", "Low", "Adj Close", "Price"]:
            if price_col in df.columns:
                essential_cols.append(price_col)
        result_df = df[essential_cols].copy() if essential_cols else pd.DataFrame(index=df.index)
        
        # Ensure Price column is always available (copy from Close if needed)
        if "Close" in df.columns and "Price" not in result_df.columns:
            result_df["Price"] = df["Close"]
            logger.info("Created 'Price' column from 'Close' values")
        
        # Check if Price column has valid values
        if "Price" in result_df.columns and (result_df["Price"].isna().all() or (result_df["Price"] == 0).all()):
            logger.warning("Price column contains all NaN or zero values!")

        # Add prediction and confidence columns
        result_df["prediction"] = highest_prob_classes  # Use highest probability class
        result_df["confidence"] = confidences
        
        # Add probability columns for each class
        for idx, class_name in enumerate(self.model.classes_):
            result_df[f"prob_{class_name}"] = probabilities[:, idx]
        
        # Calculate risk score based on confidence and prediction type
        # Higher risk for lower confidence and non-NONE predictions
        result_df["risk_score"] = 1 - result_df["confidence"]
        
        # Adjust risk tiers: Low Risk (LR) <= 0.4, High Risk (HR) > 0.4
        result_df["risk_tier"] = np.where(result_df["risk_score"] <= 0.4, "LR", "HR")
        result_df["risk_emoji"] = np.where(result_df["risk_tier"] == "LR", "🟢", "🔴")
        
        # Create prediction_with_risk that respects high confidence predictions
        result_df["prediction_with_risk"] = result_df.apply(
            lambda r: f"{r['prediction']} {r['risk_emoji']} {r['risk_tier']}",
            axis=1,
        )

        # Quick distribution logs (INFO level)
        pred_counts = pd.Series(predictions).value_counts().to_dict()
        logger.info("Prediction distribution: %s", pred_counts)
        risk_counts = result_df["risk_tier"].value_counts().to_dict()
        logger.info("Risk tier distribution: %s", risk_counts)
        
        # Log price column statistics
        price_cols = [col for col in result_df.columns if col in ["Price", "Close", "Open", "High", "Low", "Adj Close"]]
        if price_cols:
            logger.info("Price columns available: %s", price_cols)
            for col in price_cols:
                if result_df[col].isna().all() or (result_df[col] == 0).all():
                    logger.warning("%s column contains all NaN or zero values!", col)
        
        # Add key feature indicators for interpretability
        # Extract important features if they exist in X
        key_indicators = ["RSI_14", "MACD", "EMA_5", "EMA_10", "Bollinger_Upper", "Bollinger_Lower"]
        for indicator in key_indicators:
            if indicator in X.columns:
                result_df[f"indicator_{indicator}"] = X[indicator].values
                
        # Add prediction confidence distribution
        result_df["confidence_level"] = pd.cut(
            result_df["confidence"],
            bins=[0, 0.5, 0.8, 0.95, 1.0],
            labels=["Very Low", "Low", "Medium", "High"]
        )

        return result_df
