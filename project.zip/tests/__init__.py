"""Tests for the trading-stock-agents package.

This package contains unit tests and integration tests for the trading system.
"""
