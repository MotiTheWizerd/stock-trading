TICKERS = [
    "AAPL",  # Apple
]

# Alias for TICKERS to maintain consistency across refactored code
DEFAULT_TICKERS = TICKERS

START_DATE = "2023-01-01"
END_DATE = "2023-12-31"
DATA_DIR = "data"